package smybol;

public enum FuncType {
    VOID,INT
}
